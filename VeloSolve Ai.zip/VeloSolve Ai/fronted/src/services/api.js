const BASE_URL = 'http://localhost:5000/api/v1/ai';

export const ApiService = {
    async sendProblemAnalysis(problemDescription, firebaseUser) {
        // Fetch fresh authentication identity token from Firebase client
        const token = await firebaseUser.getIdToken();

        const response = await fetch(`${BASE_URL}/deconstruct`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ problemDescription })
        });

        if (!response.ok) {
            const errData = await response.json();
            throw new Error(errData.error || 'Server connection degradation.');
        }

        return await response.json();
    }
};
