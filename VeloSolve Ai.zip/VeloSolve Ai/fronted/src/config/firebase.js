import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyD8wNKssesspLbOBDKxtlcJMS1YzniG6P8",
  authDomain: "godytion-ai.firebaseapp.com",
  projectId: "godytion-ai",
  storageBucket: "godytion-ai.firebasestorage.app",
  messagingSenderId: "6405552425",
  appId: "1:6405552425:web:d9b30b5f611505f4c6fcb8",
  measurementId: "G-13VZ23WLM2"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth, signInAnonymously };
