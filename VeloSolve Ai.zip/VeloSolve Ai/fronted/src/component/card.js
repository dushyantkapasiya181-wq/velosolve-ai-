/**
 * VeloSolve AI - UI Component Generator
 * This file dynamically builds and injects the response layout.
 */

export function renderOutputCard(payload) {
    const outputSection = document.getElementById('outputSection');
    
    // Generate the step-by-step roadmap cards
    let stepsHtml = '';
    payload.roadmap.forEach(r => {
        stepsHtml += `
            <div class="step-card">
                <div class="step-badge">Step ${r.step}</div>
                <h4>${r.title}</h4>
                <p>${r.details}</p>
            </div>
        `;
    });

    // Inject the fully built clean HTML structure into the workspace
    outputSection.innerHTML = `
        <div class="card border-accent">
            <h3>🔍 Root Cause Analysis</h3>
            <p>${payload.root_cause}</p>
        </div>

        <div class="card">
            <h3>⚠️ Structural Bottlenecks</h3>
            <ul>
                ${payload.bottlenecks.map(b => `<li>${b}</li>`).join('')}
            </ul>
        </div>

        <h3 class="section-title">⚡ High-Velocity Execution Roadmap</h3>
        <div class="roadmap-container">${stepsHtml}</div>
    `;
}
