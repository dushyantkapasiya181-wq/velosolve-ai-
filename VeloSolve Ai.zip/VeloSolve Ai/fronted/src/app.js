import { auth, signInAnonymously } from './config/firebase.js';
import { ApiService } from './services/api.js';
import { renderOutputCard } from './components/Card.js';

let currentUser = null;

// UI elements cache
const submitBtn = document.getElementById('submitBtn');
const problemInput = document.getElementById('problemInput');
const authStatus = document.getElementById('authStatus');
const loadingDiv = document.getElementById('loading');
const outputSection = document.getElementById('outputSection');

// Initialize security listener authentication cycle
auth.onAuthStateChanged((user) => {
    if (user) {
        currentUser = user;
        authStatus.innerText = "Secure Connection Active";
        authStatus.style.background = "#06b6d422";
        authStatus.style.color = "#06b6d4";
        submitBtn.disabled = false;
        submitBtn.innerText = "Accelerate Solution";
    } else {
        authStatus.innerText = "Authenticating Session...";
        signInAnonymously(auth).catch(err => {
            authStatus.innerText = "Authentication Failure";
            console.error("Firebase connection blocked:", err);
        });
    }
});

submitBtn.addEventListener('click', async () => {
    const text = problemInput.value.trim();
    if (!text) return alert("Please supply problem text details.");

    loadingDiv.classList.remove('hidden');
    outputSection.classList.add('hidden');

    try {
        const result = await ApiService.sendProblemAnalysis(text, currentUser);
        renderOutputCard(result.data);
        outputSection.classList.remove('hidden');
    } catch (error) {
        alert(error.message);
    } finally {
        loadingDiv.classList.add('hidden');
    }
});
