const express = require('express');
const router = express.Router();
const analyzeController = require('../controllers/analyzeController');
const authMiddleware = require('../middleware/authMiddleware');

// Mounts authMiddleware to protect this computational engine route
router.post('/deconstruct', authMiddleware, analyzeController.deconstructProblem);

module.exports = router;
