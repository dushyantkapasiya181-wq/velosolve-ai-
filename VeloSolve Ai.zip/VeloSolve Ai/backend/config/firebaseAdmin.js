const admin = require('firebase-admin');
const dotenv = require('dotenv');

dotenv.config();

try {
    const serviceAccount = require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount)
    });
    console.log("[Firebase Admin] SDK integrated successfully.");
} catch (error) {
    console.error("[Firebase Admin Error] Missing or invalid serviceAccountKey.json:", error.message);
}

module.exports = admin;
