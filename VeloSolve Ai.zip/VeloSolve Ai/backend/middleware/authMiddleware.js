const admin = require('../config/firebaseAdmin');

module.exports = async (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Access Denied. No authorization token supplied.' });
    }

    const token = authHeader.split('Bearer ')[1];

    try {
        // Verify user identification tokens against active Firebase sessions
        const decodedToken = await admin.auth().verifyIdToken(token);
        req.user = decodedToken;
        next();
    } catch (error) {
        return res.status(403).json({ error: 'Session expired or identity validation failed.' });
    }
};
