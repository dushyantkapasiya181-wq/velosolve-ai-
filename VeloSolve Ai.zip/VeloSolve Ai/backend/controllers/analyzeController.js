const { GoogleGenAI } = require('@google/generative-ai');

exports.deconstructProblem = async (req, res) => {
    try {
        const { problemDescription } = req.body;
        
        if (!problemDescription || problemDescription.trim().length < 10) {
            return res.status(400).json({ error: 'Please supply a descriptive problem background context.' });
        }

        // Initialize secure, backend-only access to Gemini AI
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const model = ai.getGenerativeModel({ model: 'gemini-1.5-flash' });

        const systemPrompt = `
            You are an expert master strategist and problem-solver. 
            The user is facing a highly complex problem and is overwhelmed. 
            Your goal is to perform a Root Cause Analysis and break down this massive problem into exactly 3 core bottlenecks, and provide a 4-step execution roadmap.
            The very first step MUST be a micro-actionable task that takes less than 10 minutes to complete.
            
            Respond strictly in valid JSON format with the following keys:
            {
                "root_cause": "A brief sentence identifying the true hidden issue.",
                "bottlenecks": ["Bottleneck 1", "Bottleneck 2", "Bottleneck 3"],
                "roadmap": [
                    {"step": 1, "title": "10-Min Micro Action", "details": "Description"},
                    {"step": 2, "title": "Short Term Task", "details": "Description"},
                    {"step": 3, "title": "Building Momentum", "details": "Description"},
                    {"step": 4, "title": "Long Term Resolution", "details": "Description"}
                ]
            }
        `;

        const result = await model.generateContent([
            { text: systemPrompt },
            { text: `User context data: ${problemDescription}` }
        ]);

        const responseText = result.response.text();
        const cleanedJson = responseText.replace(/```json|```/g, '').trim();
        const parsedData = JSON.parse(cleanedJson);

        return res.status(200).json({
            success: true,
            userId: req.user.uid, // Access user ID safely injected by authMiddleware
            data: parsedData
        });

    } catch (error) {
        console.error('[Engine Processing Failure]:', error);
        return res.status(500).json({ error: 'Deconstruction processor structural error encountered.' });
    }
};
